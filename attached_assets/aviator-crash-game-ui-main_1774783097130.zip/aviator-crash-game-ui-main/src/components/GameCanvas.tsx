/**
 * GameCanvas — HTML5 Canvas renderer for the Aviator crash game.
 *
 * Plane sprite: /plane-sprite.png (green F-35 fighter jet, transparent BG)
 * The sprite faces upper-right in its natural orientation.
 *
 * ANCHOR POINT: The pivot is the center-bottom of the rear twin exhaust
 * nozzles (the tail). The nose leads the trajectory.
 *
 * States:
 *  1. Waiting  — plane parked at origin (0,0) at static 15° angle
 *  2. Flying   — plane follows curve tip, rotated to tangent, tail anchored
 *  3. Crashing — trail freezes gray, plane flies off with accelerating vector
 *  4. Crashed  — frozen gray trail + crash multiplier overlay
 */

import { useRef, useEffect, useCallback } from 'react'
import { cn } from '@/lib/utils'
import type { Phase, CurvePoint, PlaneTransform } from '../hooks/useGameState'

interface GameCanvasProps {
  phase: Phase
  multiplier: number
  crashPoint: number
  waitProgress: number
  trailPoints: CurvePoint[]
  plane: PlaneTransform
  betMode: 'money' | 'freebet'
  onToggleBetMode: () => void
}

const PAD = { left: 10, right: 10, top: 10, bottom: 10 }

// ── Sprite dimensions ────────────────────────────────────────────────────────
// The sprite is drawn at this CSS-pixel width; height scales proportionally.
const SPRITE_DRAW_W = 60

// The sprite's natural orientation: the nose points toward upper-right.
// We need to know the angle of the nose in the sprite's LOCAL space so we can
// compensate when rotating.  The F-35 sprite faces ~30° above horizontal-right.
const SPRITE_NATIVE_ANGLE_RAD = (30 * Math.PI) / 180

// Tail anchor offset: how many pixels from the sprite's bottom-right corner
// to the center of the exhaust nozzles (in sprite-local space at draw size).
// These are fine-tuned to pixel-match the exhaust tip.
const TAIL_OFFSET_X = -4   // px from right edge of drawn sprite
const TAIL_OFFSET_Y = 0    // px from vertical center

// ── Coordinate helpers ───────────────────────────────────────────────────────

function toPx(p: CurvePoint, w: number, h: number) {
  const dw = w - PAD.left - PAD.right
  const dh = h - PAD.top  - PAD.bottom
  return {
    cx: PAD.left + p.x * dw,
    cy: PAD.top  + (1 - p.y) * dh,
  }
}

// ── Draw functions ───────────────────────────────────────────────────────────

function drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const ox = PAD.left
  const oy = h - PAD.bottom
  const dw = w - PAD.left - PAD.right
  const dh = h - PAD.top  - PAD.bottom

  ctx.save()
  ctx.strokeStyle = 'rgba(255,255,255,0.035)'
  ctx.lineWidth   = 1

  for (let i = 1; i <= 7; i++) {
    const x = ox + (i / 8) * dw
    ctx.beginPath(); ctx.moveTo(x, PAD.top); ctx.lineTo(x, oy); ctx.stroke()
  }
  for (let i = 1; i <= 5; i++) {
    const y = oy - (i / 6) * dh
    ctx.beginPath(); ctx.moveTo(ox, y); ctx.lineTo(w - PAD.right, y); ctx.stroke()
  }

  ctx.strokeStyle = 'rgba(0,230,118,0.35)'
  ctx.lineWidth   = 1.5
  ctx.beginPath(); ctx.moveTo(ox, PAD.top); ctx.lineTo(ox, oy); ctx.stroke()
  ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(w - PAD.right, oy); ctx.stroke()

  ctx.restore()
}

function drawTrail(
  ctx: CanvasRenderingContext2D,
  w: number, h: number,
  points: CurvePoint[],
  crashed: boolean,
) {
  if (points.length < 2) return
  const ox = PAD.left
  const oy = h - PAD.bottom

  const pts = points.map(p => toPx(p, w, h))

  ctx.save()
  ctx.beginPath()
  ctx.rect(ox, PAD.top, w - PAD.left - PAD.right, oy - PAD.top)
  ctx.clip()

  ctx.beginPath()
  ctx.moveTo(pts[0].cx, pts[0].cy)
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i].cx + pts[i + 1].cx) / 2
    const my = (pts[i].cy + pts[i + 1].cy) / 2
    ctx.quadraticCurveTo(pts[i].cx, pts[i].cy, mx, my)
  }
  ctx.lineTo(pts[pts.length - 1].cx, pts[pts.length - 1].cy)

  ctx.strokeStyle = crashed ? 'rgba(160,160,160,0.5)' : '#00E676'
  ctx.lineWidth   = crashed ? 2 : 3
  ctx.lineJoin    = 'round'
  ctx.lineCap     = 'round'
  if (!crashed) { ctx.shadowColor = 'rgba(0,230,118,0.5)'; ctx.shadowBlur = 6 }
  if (crashed) ctx.setLineDash([5, 4])
  ctx.stroke()
  ctx.setLineDash([])
  ctx.shadowBlur = 0

  const last  = pts[pts.length - 1]
  const first = pts[0]
  ctx.lineTo(last.cx, oy)
  ctx.lineTo(first.cx, oy)
  ctx.closePath()

  if (crashed) {
    ctx.fillStyle = 'rgba(120,120,120,0.08)'
  } else {
    const g = ctx.createLinearGradient(0, last.cy, 0, oy)
    g.addColorStop(0,   'rgba(0,230,118,0.85)')
    g.addColorStop(0.3, 'rgba(0,210,100,0.70)')
    g.addColorStop(0.6, 'rgba(0,180,80,0.45)')
    g.addColorStop(1,   'rgba(0,140,60,0.12)')
    ctx.fillStyle = g
  }
  ctx.fill()
  ctx.restore()
}

/**
 * Draw the plane sprite with TAIL-ANCHOR pivot.
 *
 * @param ctx       Canvas context
 * @param img       Loaded sprite Image
 * @param tipX      Pixel X of the curve tip (where the tail anchors)
 * @param tipY      Pixel Y of the curve tip
 * @param angleRad  Angle of the trajectory tangent (radians, 0=right, positive=CCW)
 */
function drawPlaneSprite(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  tipX: number,
  tipY: number,
  angleRad: number,
) {
  if (!img.complete || img.naturalWidth === 0) return

  const aspect   = img.naturalHeight / img.naturalWidth
  const drawW    = SPRITE_DRAW_W
  const drawH    = drawW * aspect

  ctx.save()

  // 1. Move canvas origin to the curve's tip point
  ctx.translate(tipX, tipY)

  // 2. Rotate to the trajectory tangent.
  //    Canvas angles: 0=right, positive=clockwise.
  //    Our angleRad: 0=right, positive=counter-clockwise (math convention).
  //    The sprite naturally faces ~30° above horizontal.
  //    So we rotate by -(angleRad) to align with trajectory, then compensate
  //    for the sprite's native angle.
  ctx.rotate(-(angleRad - SPRITE_NATIVE_ANGLE_RAD))

  // 3. Offset drawing so the TAIL (exhaust nozzles at lower-left of sprite)
  //    anchors to the tip point, letting the nose point forward.
  //    The tail in the sprite is at approximately (width - |TAIL_OFFSET_X|, height/2 + TAIL_OFFSET_Y)
  //    We draw the sprite so that point lands on (0,0) which is now the tip.
  const anchorX = drawW + TAIL_OFFSET_X   // x from sprite left edge to tail
  const anchorY = drawH / 2 + TAIL_OFFSET_Y // y from sprite top edge to tail center

  ctx.drawImage(img, -anchorX, -anchorY, drawW, drawH)

  ctx.restore()
}

// ── JSX Overlays ─────────────────────────────────────────────────────────────

function BetModeToggle({ betMode, onToggle }: { betMode: 'money' | 'freebet'; onToggle: () => void }) {
  return (
    <div className="flex items-center rounded-full bg-[#111122]/90 p-0.5 border border-[#2a2a3e]">
      <button type="button" onClick={() => betMode !== 'money' && onToggle()}
        className={cn('rounded-full px-3 py-1 text-xs font-medium transition-all duration-200',
          betMode === 'money' ? 'bg-[#2a2a3e] text-foreground' : 'text-muted-foreground hover:text-foreground/70')}>
        Money
      </button>
      <button type="button" onClick={() => betMode !== 'freebet' && onToggle()}
        className={cn('rounded-full px-3 py-1 text-xs font-medium transition-all duration-200',
          betMode === 'freebet' ? 'bg-[#00E676] text-[#0d0d1a] font-semibold' : 'text-muted-foreground hover:text-foreground/70')}>
        Use Freebet
      </button>
    </div>
  )
}

function NetworkStatus() {
  return (
    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
      <span>Network Status</span>
      <span className="font-semibold text-[#00E676]">ON</span>
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#00E676] opacity-75" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#00E676]" />
      </span>
    </div>
  )
}

function TurbineSpinner() {
  return (
    <svg className="animate-spin-reverse" width="64" height="64" viewBox="0 0 64 64" fill="none">
      {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map(deg => {
        const r = (deg * Math.PI) / 180
        return (
          <path key={deg}
            d={`M${32 + 8 * Math.cos(r)},${32 + 8 * Math.sin(r)} Q${32 + 15 * Math.cos(r + 0.4)},${32 + 15 * Math.sin(r + 0.4)} ${32 + 26 * Math.cos(r)},${32 + 26 * Math.sin(r)}`}
            stroke="#00E676" strokeWidth="2.5" strokeLinecap="round" opacity="0.8" />
        )
      })}
      <circle cx="32" cy="32" r="5" fill="#00E676" />
      <circle cx="32" cy="32" r="2.5" fill="#0d0d1a" />
    </svg>
  )
}

function DecorationDots() {
  return (
    <>
      <div className="absolute bottom-1.5 left-6 right-4 flex justify-between pointer-events-none z-[2]">
        {Array.from({ length: 12 }, (_, i) => (
          <div key={`b-${i}`} className="h-1.5 w-1.5 rounded-full bg-[#00E676]"
            style={{ animation: 'dotGlow 2.4s linear infinite', animationDelay: `${(11 - i) * 0.2}s` }} />
        ))}
      </div>
      <div className="absolute left-1.5 top-12 bottom-4 flex flex-col justify-between pointer-events-none z-[2]">
        {Array.from({ length: 9 }, (_, i) => (
          <div key={`l-${i}`} className="h-1.5 w-1.5 rounded-full bg-[#00E676]"
            style={{ animation: 'dotGlow 2.7s linear infinite', animationDelay: `${(8 - i) * 0.3}s` }} />
        ))}
      </div>
    </>
  )
}

function getCrashColor(v: number): string {
  if (v >= 10) return '#E91E63'
  if (v >= 2)  return '#FF9800'
  return '#00E676'
}

// ── Main Component ───────────────────────────────────────────────────────────

export function GameCanvas({
  phase, multiplier, crashPoint, waitProgress,
  trailPoints, plane, betMode, onToggleBetMode,
}: GameCanvasProps) {
  const canvasRef    = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const spriteRef    = useRef<HTMLImageElement | null>(null)
  const bobRef       = useRef(0)
  const bobRaf       = useRef(0)
  const bobT0        = useRef(0)

  // Load the sprite once
  useEffect(() => {
    const img = new Image()
    img.src = '/plane-sprite.png'
    img.onload = () => { spriteRef.current = img }
    spriteRef.current = img
  }, [])

  // ── Render ──────────────────────────────────────────────────────────────
  const render = useCallback(() => {
    const cvs = canvasRef.current
    if (!cvs) return
    const ctx = cvs.getContext('2d')
    if (!ctx) return

    const CW  = cvs.clientWidth  || cvs.width
    const CH  = cvs.clientHeight || cvs.height
    const dpr = window.devicePixelRatio || 1
    const pw  = Math.round(CW * dpr)
    const ph  = Math.round(CH * dpr)

    if (cvs.width !== pw || cvs.height !== ph) {
      cvs.width = pw; cvs.height = ph
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }

    ctx.clearRect(0, 0, CW, CH)

    const isCrashing = phase === 'crashing'
    const isCrashed  = phase === 'crashed'
    const isFlying   = phase === 'flying'
    const isWaiting  = phase === 'waiting'

    const dw = CW - PAD.left - PAD.right
    const dh = CH - PAD.top  - PAD.bottom

    // Origin point (0,0) of the graph = bottom-left of draw area
    const originX = PAD.left
    const originY = CH - PAD.bottom

    drawGrid(ctx, CW, CH)

    // ── STATE 1: WAITING — plane parked at origin, static 15° ────────────
    if (isWaiting && spriteRef.current) {
      const waitAngleRad = (15 * Math.PI) / 180
      drawPlaneSprite(ctx, spriteRef.current, originX, originY, waitAngleRad)
    }

    // ── STATE 2: FLYING — trail + plane following curve tip ──────────────
    if (isFlying && trailPoints.length >= 2) {
      drawTrail(ctx, CW, CH, trailPoints, false)
    }

    if (isFlying && spriteRef.current && !plane.offScreen) {
      const tipX = PAD.left + plane.nx * dw
      const tipY = PAD.top  + (1 - plane.ny) * dh

      // Bob offset (gentle sway)
      const bob = bobRef.current

      // Compute tangent angle from the plane's angleDeg
      const angleRad = (plane.angleDeg * Math.PI) / 180

      drawPlaneSprite(ctx, spriteRef.current, tipX, tipY + bob, angleRad)
    }

    // ── STATE 3: CRASHING — frozen gray trail + plane flying off ─────────
    if (isCrashing && trailPoints.length >= 2) {
      drawTrail(ctx, CW, CH, trailPoints, true)
    }

    if (isCrashing && spriteRef.current && !plane.offScreen) {
      const baseTipX = PAD.left + plane.nx * dw
      const baseTipY = PAD.top  + (1 - plane.ny) * dh

      const flyX = baseTipX + plane.crashOffsetX * dw
      const flyY = baseTipY + plane.crashOffsetY * dh

      const angleRad = (plane.angleDeg * Math.PI) / 180

      drawPlaneSprite(ctx, spriteRef.current, flyX, flyY, angleRad)
    }

    // ── STATE 4: CRASHED — frozen gray trail only (no plane) ────────────
    if (isCrashed && trailPoints.length >= 2) {
      drawTrail(ctx, CW, CH, trailPoints, true)
    }
  }, [phase, multiplier, trailPoints, plane])

  useEffect(() => { render() }, [render])

  // ── Bob loop ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (phase !== 'flying') {
      cancelAnimationFrame(bobRaf.current)
      bobRef.current = 0
      return
    }
    bobT0.current = performance.now()
    const loop = (now: number) => {
      const t   = (now - bobT0.current) / 1000
      const amp = Math.min(4, 1.5 + t * 0.04)
      bobRef.current = Math.sin(t * 2.2) * amp
      render()
      bobRaf.current = requestAnimationFrame(loop)
    }
    bobRaf.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(bobRaf.current)
  }, [phase, render])

  // ── Resize ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const c = containerRef.current
    const v = canvasRef.current
    if (!c || !v) return
    const { width, height } = c.getBoundingClientRect()
    v.width = width; v.height = height
    render()
    const ro = new ResizeObserver(() => {
      const r = c.getBoundingClientRect()
      v.width = r.width; v.height = r.height
      render()
    })
    ro.observe(c)
    return () => ro.disconnect()
  }, [render])

  const glow = phase === 'flying' ? Math.min(0.5, (multiplier - 1) / 16) : 0
  const cc   = getCrashColor(crashPoint)

  return (
    <div ref={containerRef}
      className={cn('game-canvas-bg relative rounded-lg border border-[#2a2a3e]',
        'aspect-[4/3] w-full select-none overflow-hidden')}>

      <canvas ref={canvasRef} className="absolute inset-0 z-[1] w-full h-full" aria-hidden="true" />

      {/* Warm glow */}
      <div className="absolute inset-0 pointer-events-none z-0"
        style={{
          background: `radial-gradient(ellipse 50% 40% at 65% 50%, rgba(200,50,0,${glow}) 0%, transparent 70%)`,
          transition: 'background 1s ease',
        }} />

      {/* Controls */}
      <div className="absolute left-3 top-2.5 z-10 flex flex-col gap-0.5">
        <BetModeToggle betMode={betMode} onToggle={onToggleBetMode} />
        <NetworkStatus />
      </div>

      <DecorationDots />

      {/* WAITING overlay — progress bar + text (plane drawn on canvas now) */}
      {phase === 'waiting' && (
        <div className="absolute inset-0 z-[5] flex flex-col items-center justify-center gap-4 px-6">
          <TurbineSpinner />
          <p className="text-sm font-bold uppercase tracking-wider text-foreground">
            Waiting for next round
          </p>
          <div className="h-2 w-48 max-w-[70%] overflow-hidden rounded-full bg-[#2a2a3e]">
            <div className="h-full rounded-full bg-[#00E676] transition-[width] duration-100 ease-linear"
              style={{ width: `${waitProgress}%` }} />
          </div>
        </div>
      )}

      {/* FLYING */}
      {phase === 'flying' && (
        <div className="absolute inset-0 z-[4] flex items-center justify-center pointer-events-none">
          <div className="flex items-baseline font-mono drop-shadow-lg" style={{ marginTop: '-10%' }}>
            <span className="font-bold text-foreground" style={{ fontSize: 'clamp(2rem, 8vw, 3.5rem)' }}>
              {multiplier.toFixed(2)}
            </span>
            <span className="ml-1 font-bold text-foreground/50" style={{ fontSize: 'clamp(1.2rem, 5vw, 2rem)' }}>x</span>
          </div>
        </div>
      )}

      {/* CRASHING */}
      {phase === 'crashing' && (
        <div className="absolute inset-0 z-[4] flex flex-col items-center justify-center gap-1 pointer-events-none" style={{ marginTop: '-8%' }}>
          <p className="text-sm font-bold uppercase tracking-widest" style={{ color: cc }}>Flew away!</p>
          <div className="flex items-baseline font-mono">
            <span className="font-bold drop-shadow-lg" style={{ fontSize: 'clamp(2rem,7vw,3rem)', color: cc }}>{crashPoint.toFixed(2)}</span>
            <span className="ml-1 font-bold" style={{ fontSize: 'clamp(1.1rem,4vw,1.8rem)', color: cc + '88' }}>x</span>
          </div>
        </div>
      )}

      {/* CRASHED */}
      {phase === 'crashed' && (
        <div className="absolute inset-0 z-[5] flex flex-col items-center justify-center gap-2 px-6" style={{ marginTop: '-5%' }}>
          <p className="text-base font-bold uppercase tracking-widest text-foreground">Flew away!</p>
          <div className="flex items-baseline font-mono">
            <span className="font-bold" style={{ fontSize: 'clamp(2.2rem,8vw,3.5rem)', color: cc }}>{crashPoint.toFixed(2)}</span>
            <span className="ml-1 font-bold" style={{ fontSize: 'clamp(1.2rem,5vw,2rem)', color: cc + '99' }}>x</span>
          </div>
        </div>
      )}
    </div>
  )
}
