/**
 * GameCanvas — HTML5 Canvas renderer for the Aviator crash game.
 *
 * Clean animation matching authentic Aviator casino game style:
 * - Smooth exponential curve from bottom-left to upper-right
 * - Vibrant green gradient fill under the curve
 * - Plane sprite positioned at curve tip with proper rotation
 */

import { useRef, useEffect, useCallback } from 'react'
import { cn } from '@/lib/utils'
import type { Phase, CurvePoint, PlaneTransform } from '../hooks/useGameState'

interface GameCanvasProps {
  phase: Phase
  multiplier: number
  crashPoint: number
  waitProgress: number
  trailPoints: CurvePoint[]
  plane: PlaneTransform
  betMode: 'money' | 'freebet'
  onToggleBetMode: () => void
}

const PAD = { left: 40, right: 20, top: 60, bottom: 40 }

// ── Sprite dimensions ────────────────────────────────────────────────────────
const SPRITE_DRAW_W = 80
const SPRITE_NATIVE_ANGLE_RAD = (30 * Math.PI) / 180
const TAIL_OFFSET_X = -8
const TAIL_OFFSET_Y = 0

// ── Coordinate helpers ───────────────────────────────────────────────────────

function toPx(p: CurvePoint, w: number, h: number) {
  const dw = w - PAD.left - PAD.right
  const dh = h - PAD.top - PAD.bottom
  return {
    cx: PAD.left + p.x * dw,
    cy: PAD.top + (1 - p.y) * dh,
  }
}

// ── Draw functions ───────────────────────────────────────────────────────────

function drawBackground(ctx: CanvasRenderingContext2D, w: number, h: number) {
  // Dark gradient background
  const bgGrad = ctx.createLinearGradient(0, 0, 0, h)
  bgGrad.addColorStop(0, '#0f1923')
  bgGrad.addColorStop(0.5, '#101820')
  bgGrad.addColorStop(1, '#0d1218')
  ctx.fillStyle = bgGrad
  ctx.fillRect(0, 0, w, h)

  // Subtle radial glow in center
  const radGrad = ctx.createRadialGradient(w * 0.5, h * 0.4, 0, w * 0.5, h * 0.4, w * 0.6)
  radGrad.addColorStop(0, 'rgba(0, 50, 30, 0.15)')
  radGrad.addColorStop(1, 'transparent')
  ctx.fillStyle = radGrad
  ctx.fillRect(0, 0, w, h)
}

function drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const ox = PAD.left
  const oy = h - PAD.bottom
  const dw = w - PAD.left - PAD.right
  const dh = h - PAD.top - PAD.bottom

  ctx.save()

  // Subtle grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.03)'
  ctx.lineWidth = 1

  // Vertical lines
  for (let i = 1; i <= 8; i++) {
    const x = ox + (i / 9) * dw
    ctx.beginPath()
    ctx.moveTo(x, PAD.top)
    ctx.lineTo(x, oy)
    ctx.stroke()
  }

  // Horizontal lines
  for (let i = 1; i <= 6; i++) {
    const y = oy - (i / 7) * dh
    ctx.beginPath()
    ctx.moveTo(ox, y)
    ctx.lineTo(w - PAD.right, y)
    ctx.stroke()
  }

  // Main axes with green glow
  ctx.strokeStyle = 'rgba(0,230,118,0.6)'
  ctx.lineWidth = 2
  ctx.shadowColor = 'rgba(0,230,118,0.4)'
  ctx.shadowBlur = 8

  // Y-axis
  ctx.beginPath()
  ctx.moveTo(ox, PAD.top)
  ctx.lineTo(ox, oy)
  ctx.stroke()

  // X-axis
  ctx.beginPath()
  ctx.moveTo(ox, oy)
  ctx.lineTo(w - PAD.right, oy)
  ctx.stroke()

  ctx.shadowBlur = 0
  ctx.restore()
}

function drawTrail(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  points: CurvePoint[],
  crashed: boolean
) {
  if (points.length < 2) return
  const ox = PAD.left
  const oy = h - PAD.bottom

  const pts = points.map((p) => toPx(p, w, h))

  ctx.save()

  // Clip to graph area
  ctx.beginPath()
  ctx.rect(ox, PAD.top, w - PAD.left - PAD.right, oy - PAD.top)
  ctx.clip()

  // Build the curve path
  ctx.beginPath()
  ctx.moveTo(pts[0].cx, pts[0].cy)

  // Smooth curve using quadratic bezier
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i].cx + pts[i + 1].cx) / 2
    const my = (pts[i].cy + pts[i + 1].cy) / 2
    ctx.quadraticCurveTo(pts[i].cx, pts[i].cy, mx, my)
  }
  ctx.lineTo(pts[pts.length - 1].cx, pts[pts.length - 1].cy)

  // Store the path for stroke
  const curvePath = new Path2D()
  curvePath.moveTo(pts[0].cx, pts[0].cy)
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i].cx + pts[i + 1].cx) / 2
    const my = (pts[i].cy + pts[i + 1].cy) / 2
    curvePath.quadraticCurveTo(pts[i].cx, pts[i].cy, mx, my)
  }
  curvePath.lineTo(pts[pts.length - 1].cx, pts[pts.length - 1].cy)

  // Draw fill area first
  const last = pts[pts.length - 1]
  const first = pts[0]

  ctx.lineTo(last.cx, oy)
  ctx.lineTo(first.cx, oy)
  ctx.closePath()

  if (crashed) {
    ctx.fillStyle = 'rgba(80,80,80,0.15)'
  } else {
    // Vibrant green gradient fill - matching Aviator style
    const g = ctx.createLinearGradient(0, last.cy, 0, oy)
    g.addColorStop(0, 'rgba(0,230,118,0.95)')
    g.addColorStop(0.2, 'rgba(0,210,100,0.85)')
    g.addColorStop(0.4, 'rgba(0,180,80,0.65)')
    g.addColorStop(0.6, 'rgba(0,150,60,0.45)')
    g.addColorStop(0.8, 'rgba(0,120,50,0.25)')
    g.addColorStop(1, 'rgba(0,80,40,0.08)')
    ctx.fillStyle = g
  }
  ctx.fill()

  // Draw the curve stroke on top
  if (crashed) {
    ctx.strokeStyle = 'rgba(120,120,120,0.6)'
    ctx.lineWidth = 3
    ctx.setLineDash([6, 4])
  } else {
    ctx.strokeStyle = '#00E676'
    ctx.lineWidth = 4
    ctx.shadowColor = 'rgba(0,230,118,0.8)'
    ctx.shadowBlur = 12
  }

  ctx.lineJoin = 'round'
  ctx.lineCap = 'round'
  ctx.stroke(curvePath)

  // Draw a second, thinner bright line for extra glow
  if (!crashed) {
    ctx.strokeStyle = 'rgba(150,255,200,0.5)'
    ctx.lineWidth = 2
    ctx.shadowBlur = 0
    ctx.stroke(curvePath)
  }

  ctx.setLineDash([])
  ctx.shadowBlur = 0
  ctx.restore()
}

/**
 * Draw the plane sprite with TAIL-ANCHOR pivot.
 */
function drawPlaneSprite(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  tipX: number,
  tipY: number,
  angleRad: number
) {
  if (!img.complete || img.naturalWidth === 0) return

  const aspect = img.naturalHeight / img.naturalWidth
  const drawW = SPRITE_DRAW_W
  const drawH = drawW * aspect

  ctx.save()

  // Add glow effect behind the plane
  ctx.shadowColor = 'rgba(0,230,118,0.6)'
  ctx.shadowBlur = 20

  // Move canvas origin to the curve's tip point
  ctx.translate(tipX, tipY)

  // Rotate to the trajectory tangent
  ctx.rotate(-(angleRad - SPRITE_NATIVE_ANGLE_RAD))

  // Offset drawing so the TAIL anchors to the tip point
  const anchorX = drawW + TAIL_OFFSET_X
  const anchorY = drawH / 2 + TAIL_OFFSET_Y

  ctx.drawImage(img, -anchorX, -anchorY, drawW, drawH)

  ctx.restore()
}

// Draw engine exhaust/trail effect
function drawExhaust(
  ctx: CanvasRenderingContext2D,
  tipX: number,
  tipY: number,
  angleRad: number,
  time: number
) {
  ctx.save()
  ctx.translate(tipX, tipY)
  ctx.rotate(-angleRad)

  // Animated exhaust particles
  const numParticles = 8
  for (let i = 0; i < numParticles; i++) {
    const offset = (time * 0.003 + i * 0.15) % 1
    const x = -20 - offset * 60
    const y = (Math.sin(time * 0.01 + i) * 3)
    const size = (1 - offset) * 6 + 2
    const alpha = (1 - offset) * 0.6

    ctx.beginPath()
    ctx.arc(x, y, size, 0, Math.PI * 2)
    ctx.fillStyle = `rgba(0,230,118,${alpha})`
    ctx.fill()
  }

  ctx.restore()
}

// ── JSX Overlays ─────────────────────────────────────────────────────────────

function BetModeToggle({
  betMode,
  onToggle,
}: {
  betMode: 'money' | 'freebet'
  onToggle: () => void
}) {
  return (
    <div className="flex items-center rounded-full bg-[#1a1a2e]/95 p-0.5 border border-[#2a2a3e] backdrop-blur-sm">
      <button
        type="button"
        onClick={() => betMode !== 'money' && onToggle()}
        className={cn(
          'rounded-full px-4 py-1.5 text-xs font-semibold transition-all duration-200',
          betMode === 'money'
            ? 'bg-[#2a2a3e] text-foreground'
            : 'text-muted-foreground hover:text-foreground/70'
        )}
      >
        Money
      </button>
      <button
        type="button"
        onClick={() => betMode !== 'freebet' && onToggle()}
        className={cn(
          'rounded-full px-4 py-1.5 text-xs font-semibold transition-all duration-200',
          betMode === 'freebet'
            ? 'bg-[#00E676] text-[#0d0d1a]'
            : 'text-muted-foreground hover:text-foreground/70'
        )}
      >
        Use Freebet
      </button>
    </div>
  )
}

function NetworkStatus() {
  return (
    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
      <span>Network Status</span>
      <span className="font-bold text-[#00E676]">ON</span>
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#00E676] opacity-75" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-[#00E676]" />
      </span>
    </div>
  )
}

function TurbineSpinner() {
  return (
    <svg
      className="animate-spin-reverse"
      width="80"
      height="80"
      viewBox="0 0 64 64"
      fill="none"
    >
      {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => {
        const r = (deg * Math.PI) / 180
        return (
          <path
            key={deg}
            d={`M${32 + 8 * Math.cos(r)},${32 + 8 * Math.sin(r)} Q${32 + 15 * Math.cos(r + 0.4)},${32 + 15 * Math.sin(r + 0.4)} ${32 + 26 * Math.cos(r)},${32 + 26 * Math.sin(r)}`}
            stroke="#00E676"
            strokeWidth="2.5"
            strokeLinecap="round"
            opacity="0.8"
          />
        )
      })}
      <circle cx="32" cy="32" r="5" fill="#00E676" />
      <circle cx="32" cy="32" r="2.5" fill="#0d0d1a" />
    </svg>
  )
}

function DecorationDots() {
  return (
    <>
      {/* Bottom axis dots */}
      <div className="absolute bottom-[38px] left-[40px] right-[20px] flex justify-between pointer-events-none z-[2]">
        {Array.from({ length: 14 }, (_, i) => (
          <div
            key={`b-${i}`}
            className="h-2 w-2 rounded-full"
            style={{
              backgroundColor: '#00E676',
              opacity: 0.7,
              animation: 'dotPulse 2s ease-in-out infinite',
              animationDelay: `${i * 0.1}s`,
            }}
          />
        ))}
      </div>
      {/* Left axis dots */}
      <div className="absolute left-[18px] top-[60px] bottom-[40px] flex flex-col justify-between pointer-events-none z-[2]">
        {Array.from({ length: 10 }, (_, i) => (
          <div
            key={`l-${i}`}
            className="h-2 w-2 rounded-full"
            style={{
              backgroundColor: '#00E676',
              opacity: 0.7,
              animation: 'dotPulse 2.5s ease-in-out infinite',
              animationDelay: `${i * 0.15}s`,
            }}
          />
        ))}
      </div>
    </>
  )
}

function getCrashColor(v: number): string {
  if (v >= 10) return '#E91E63'
  if (v >= 2) return '#FF9800'
  return '#00E676'
}

// ── Main Component ───────────────────────────────────────────────────────────

export function GameCanvas({
  phase,
  multiplier,
  crashPoint,
  waitProgress,
  trailPoints,
  plane,
  betMode,
  onToggleBetMode,
}: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const spriteRef = useRef<HTMLImageElement | null>(null)
  const bobRef = useRef(0)
  const timeRef = useRef(0)
  const rafRef = useRef(0)
  const bobT0 = useRef(0)

  // Load the sprite once
  useEffect(() => {
    const img = new Image()
    img.src = '/plane-sprite.png'
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      spriteRef.current = img
    }
    spriteRef.current = img
  }, [])

  // ── Render ──────────────────────────────────────────────────────────────
  const render = useCallback(
    (time: number = 0) => {
      const cvs = canvasRef.current
      if (!cvs) return
      const ctx = cvs.getContext('2d')
      if (!ctx) return

      timeRef.current = time

      const CW = cvs.clientWidth || cvs.width
      const CH = cvs.clientHeight || cvs.height
      const dpr = window.devicePixelRatio || 1
      const pw = Math.round(CW * dpr)
      const ph = Math.round(CH * dpr)

      if (cvs.width !== pw || cvs.height !== ph) {
        cvs.width = pw
        cvs.height = ph
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      }

      // Clear and draw background
      ctx.clearRect(0, 0, CW, CH)
      drawBackground(ctx, CW, CH)

      const isCrashing = phase === 'crashing'
      const isCrashed = phase === 'crashed'
      const isFlying = phase === 'flying'
      const isWaiting = phase === 'waiting'

      const dw = CW - PAD.left - PAD.right
      const dh = CH - PAD.top - PAD.bottom

      // Origin point (0,0) of the graph = bottom-left of draw area
      const originX = PAD.left
      const originY = CH - PAD.bottom

      drawGrid(ctx, CW, CH)

      // ── STATE 1: WAITING — plane parked at origin, static angle ────────────
      if (isWaiting && spriteRef.current) {
        const waitAngleRad = (20 * Math.PI) / 180
        drawPlaneSprite(ctx, spriteRef.current, originX, originY, waitAngleRad)
      }

      // ── STATE 2: FLYING — trail + plane following curve tip ──────────────
      if (isFlying && trailPoints.length >= 2) {
        drawTrail(ctx, CW, CH, trailPoints, false)
      }

      if (isFlying && spriteRef.current && !plane.offScreen) {
        const tipX = PAD.left + plane.nx * dw
        const tipY = PAD.top + (1 - plane.ny) * dh

        // Bob offset (gentle sway)
        const bob = bobRef.current

        // Compute tangent angle from the plane's angleDeg
        const angleRad = (plane.angleDeg * Math.PI) / 180

        // Draw exhaust effect
        drawExhaust(ctx, tipX, tipY + bob, angleRad, time)

        // Draw plane
        drawPlaneSprite(ctx, spriteRef.current, tipX, tipY + bob, angleRad)
      }

      // ── STATE 3: CRASHING — frozen gray trail + plane flying off ─────────
      if (isCrashing && trailPoints.length >= 2) {
        drawTrail(ctx, CW, CH, trailPoints, true)
      }

      if (isCrashing && spriteRef.current && !plane.offScreen) {
        const baseTipX = PAD.left + plane.nx * dw
        const baseTipY = PAD.top + (1 - plane.ny) * dh

        const flyX = baseTipX + plane.crashOffsetX * dw
        const flyY = baseTipY + plane.crashOffsetY * dh

        const angleRad = (plane.angleDeg * Math.PI) / 180

        drawPlaneSprite(ctx, spriteRef.current, flyX, flyY, angleRad)
      }

      // ── STATE 4: CRASHED — frozen gray trail only (no plane) ────────────
      if (isCrashed && trailPoints.length >= 2) {
        drawTrail(ctx, CW, CH, trailPoints, true)
      }
    },
    [phase, trailPoints, plane]
  )

  useEffect(() => {
    render(performance.now())
  }, [render])

  // ── Animation loop ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (phase !== 'flying') {
      cancelAnimationFrame(rafRef.current)
      bobRef.current = 0
      return
    }
    bobT0.current = performance.now()

    const loop = (now: number) => {
      const t = (now - bobT0.current) / 1000
      // Gentle bob amplitude
      const amp = Math.min(3, 1 + t * 0.02)
      bobRef.current = Math.sin(t * 2.5) * amp
      render(now)
      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(rafRef.current)
  }, [phase, render])

  // ── Resize ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const c = containerRef.current
    const v = canvasRef.current
    if (!c || !v) return
    const { width, height } = c.getBoundingClientRect()
    v.width = width
    v.height = height
    render(performance.now())
    const ro = new ResizeObserver(() => {
      const r = c.getBoundingClientRect()
      v.width = r.width
      v.height = r.height
      render(performance.now())
    })
    ro.observe(c)
    return () => ro.disconnect()
  }, [render])

  const cc = getCrashColor(crashPoint)

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative rounded-xl border border-[#1a2a1a] overflow-hidden',
        'aspect-[16/10] w-full select-none'
      )}
      style={{
        background: 'linear-gradient(180deg, #0f1923 0%, #101820 50%, #0d1218 100%)',
      }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-[1] w-full h-full"
        aria-hidden="true"
      />

      {/* Controls */}
      <div className="absolute left-3 top-3 z-10 flex flex-col gap-1">
        <BetModeToggle betMode={betMode} onToggle={onToggleBetMode} />
        <NetworkStatus />
      </div>

      <DecorationDots />

      {/* WAITING overlay */}
      {phase === 'waiting' && (
        <div className="absolute inset-0 z-[5] flex flex-col items-center justify-center gap-5 px-6">
          <TurbineSpinner />
          <p className="text-base font-bold uppercase tracking-widest text-foreground">
            Waiting for next round
          </p>
          <div className="h-2.5 w-56 max-w-[70%] overflow-hidden rounded-full bg-[#1a2a1a] border border-[#2a3a2a]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#00E676] to-[#00C853] transition-[width] duration-100 ease-linear"
              style={{ width: `${waitProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* FLYING - Multiplier Display */}
      {phase === 'flying' && (
        <div className="absolute inset-0 z-[4] flex items-center justify-center pointer-events-none">
          <div
            className="flex items-baseline font-mono"
            style={{ marginTop: '-5%' }}
          >
            <span
              className="font-black text-foreground drop-shadow-[0_0_30px_rgba(255,255,255,0.3)]"
              style={{ fontSize: 'clamp(3rem, 12vw, 5rem)' }}
            >
              {multiplier.toFixed(2)}
            </span>
            <span
              className="ml-2 font-bold text-foreground/60"
              style={{ fontSize: 'clamp(1.5rem, 6vw, 2.5rem)' }}
            >
              x
            </span>
          </div>
        </div>
      )}

      {/* CRASHING */}
      {phase === 'crashing' && (
        <div
          className="absolute inset-0 z-[4] flex flex-col items-center justify-center gap-2 pointer-events-none"
          style={{ marginTop: '-5%' }}
        >
          <p
            className="text-lg font-black uppercase tracking-widest"
            style={{ color: cc }}
          >
            Flew away!
          </p>
          <div className="flex items-baseline font-mono">
            <span
              className="font-black drop-shadow-lg"
              style={{ fontSize: 'clamp(3rem, 10vw, 4.5rem)', color: cc }}
            >
              {crashPoint.toFixed(2)}
            </span>
            <span
              className="ml-2 font-bold"
              style={{ fontSize: 'clamp(1.5rem, 5vw, 2.2rem)', color: cc + 'aa' }}
            >
              x
            </span>
          </div>
        </div>
      )}

      {/* CRASHED */}
      {phase === 'crashed' && (
        <div
          className="absolute inset-0 z-[5] flex flex-col items-center justify-center gap-3 px-6"
          style={{ marginTop: '-5%' }}
        >
          <p className="text-xl font-black uppercase tracking-widest text-foreground">
            Flew away!
          </p>
          <div className="flex items-baseline font-mono">
            <span
              className="font-black"
              style={{ fontSize: 'clamp(3.5rem, 12vw, 5rem)', color: cc }}
            >
              {crashPoint.toFixed(2)}
            </span>
            <span
              className="ml-2 font-bold"
              style={{ fontSize: 'clamp(1.8rem, 6vw, 2.8rem)', color: cc + 'bb' }}
            >
              x
            </span>
          </div>
        </div>
      )}
    </div>
  )
}
