interface RoundHistoryProps {
  history: number[]
}

function getMultiplierColor(value: number): string {
  if (value >= 10) return 'text-[#E91E63]'
  if (value >= 2) return 'text-[#FF9800]'
  return 'text-[#00E676]'
}

export function RoundHistory({ history }: RoundHistoryProps) {
  const reversed = [...history].reverse()

  return (
    <div className="flex items-center bg-[#12121f] px-4 py-2">
      {/* Scrollable multiplier strip */}
      <div className="flex-1 flex items-center gap-2 overflow-x-auto hide-scrollbar min-w-0">
        {reversed.map((multiplier, index) => (
          <span
            key={`${index}-${multiplier}`}
            className={`shrink-0 rounded-full bg-[#1a1a2e] px-3 py-1 text-sm font-bold font-mono ${getMultiplierColor(multiplier)}`}
          >
            {multiplier.toFixed(2)}x
          </span>
        ))}
      </div>

      {/* Action icons */}
      <div className="flex items-center gap-1.5 ml-2 shrink-0">
        {/* Clock / history icon */}
        <button
          type="button"
          aria-label="History"
          className="bg-[#1a1a2e] p-1.5 rounded-md text-[#888888] transition-colors duration-150 hover:bg-[#25253d] hover:text-[#aaaaaa]"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
        </button>

        {/* Filter / dropdown icon */}
        <button
          type="button"
          aria-label="Filter"
          className="bg-[#1a1a2e] p-1.5 rounded-md text-[#888888] transition-colors duration-150 hover:bg-[#25253d] hover:text-[#aaaaaa]"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </button>
      </div>
    </div>
  )
}
