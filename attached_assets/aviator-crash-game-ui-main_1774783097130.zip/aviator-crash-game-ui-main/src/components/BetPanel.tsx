import { useState } from 'react'

interface BetPanelProps {
  defaultAmount?: number
  currency?: string
  showLiveBets?: boolean
}

const QUICK_AMOUNTS = [10, 100, 1000, 10000] as const
const STEP = 10
const MIN_AMOUNT = 0

type Tab = 'bet' | 'auto'
type LiveTab = 'live' | 'mine'

const MOCK_LIVE_BETS = [
  { id: 1, user: '2**2', bet: 3680.00, cashout: 12.56, won: 46222.78, color: '#E91E63', high: true },
  { id: 2, user: '2**4', bet: 3620.00, cashout: 1.45, won: 5248.77, color: '#FF9800', high: false },
  { id: 3, user: '2**9', bet: 3590.00, cashout: 1.31, won: 4702.77, color: '#2196F3', high: false },
  { id: 4, user: '2**0', bet: 3580.00, cashout: 1.70, won: 6085.71, color: '#9C27B0', high: false },
  { id: 5, user: '2**8', bet: 3570.00, cashout: 1.10, won: 3926.88, color: '#00BCD4', high: false },
  { id: 6, user: '2**9', bet: 3300.00, cashout: 1.63, won: 5379.00, color: '#FF5722', high: false },
  { id: 7, user: '2**7', bet: 3270.00, cashout: 1.37, won: 4479.67, color: '#4CAF50', high: false },
  { id: 8, user: '2**3', bet: 3140.00, cashout: 10.24, won: 32152.26, color: '#E91E63', high: true },
  { id: 9, user: '2**8', bet: 2310.00, cashout: 1.37, won: 3164.35, color: '#F44336', high: false },
  { id: 10, user: '2**5', bet: 1990.00, cashout: 1.36, won: 2706.28, color: '#8BC34A', high: false },
  { id: 11, user: '2**8', bet: 1420.00, cashout: 5.45, won: 7738.88, color: '#FF9800', high: true },
  { id: 12, user: '2**6', bet: 1390.00, cashout: 1.38, won: 1918.31, color: '#3F51B5', high: false },
]

function getCashoutColor(v: number): string {
  if (v >= 10) return '#E91E63'
  if (v >= 2) return '#FF9800'
  return '#cdd2db'
}

export default function BetPanel({
  defaultAmount = 10,
  currency = 'KSH',
  showLiveBets = false,
}: BetPanelProps) {
  const [amount, setAmount] = useState(defaultAmount)
  const [activeTab, setActiveTab] = useState<Tab>('bet')
  const [liveTab, setLiveTab] = useState<LiveTab>('live')

  const decrease = () => setAmount((prev) => Math.max(MIN_AMOUNT, Number((prev - STEP).toFixed(2))))
  const increase = () => setAmount((prev) => Number((prev + STEP).toFixed(2)))

  return (
    <div className="flex flex-col gap-0">
      <div className="rounded-xl border border-[#2a2a3e] bg-[#1a1a2e] p-4">
        {/* Tab Switcher */}
        <div className="mx-auto mb-4 flex w-[220px] rounded-full bg-[#12121f] p-1">
          <TabButton label="Bet" active={activeTab === 'bet'} onClick={() => setActiveTab('bet')} />
          <TabButton label="Auto" active={activeTab === 'auto'} onClick={() => setActiveTab('auto')} />
        </div>

        {/* Amount Controls + BET Button */}
        <div className="flex flex-row gap-4">
          {/* Left — Amount Controls */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={decrease}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-[#3a3a4e] bg-[#2a2a3e] text-lg font-bold text-foreground transition-colors hover:border-[#00E676]/30 active:scale-95"
              >
                −
              </button>
              <span className="min-w-[60px] text-center font-mono text-lg font-bold text-foreground">
                {amount % 1 === 0 ? amount.toLocaleString() : amount.toFixed(2)}
              </span>
              <button
                type="button"
                onClick={increase}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-[#3a3a4e] bg-[#2a2a3e] text-lg font-bold text-foreground transition-colors hover:border-[#00E676]/30 active:scale-95"
              >
                +
              </button>
            </div>
            {/* Quick Amount Grid */}
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {QUICK_AMOUNTS.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAmount(value)}
                  className="rounded-md border border-[#2a2a3e] bg-[#12121f] px-2 py-1 font-mono text-xs text-muted-foreground transition-colors hover:border-[#00E676]/30"
                >
                  {value.toLocaleString()}
                </button>
              ))}
            </div>
          </div>

          {/* Right — BET Button */}
          <button
            type="button"
            className="flex flex-1 flex-col items-center justify-center rounded-xl bg-[#00E676] px-8 py-6 transition-all duration-150 ease-in-out hover:brightness-110 hover:scale-[1.02] active:scale-[0.98]"
          >
            <span className="text-xl font-bold text-[#0d0d1a]">BET</span>
            <span className="text-sm font-medium text-[#0d0d1a]/80">
              {amount.toFixed(2)} {currency}
            </span>
          </button>
        </div>
      </div>

      {/* Live Bets Section — only shown on the second panel */}
      {showLiveBets && (
        <div className="rounded-xl border border-[#2a2a3e] bg-[#1a1a2e] mt-3 overflow-hidden">
          {/* Live Bets Tabs */}
          <div className="flex gap-0 p-3 pb-0">
            <button
              type="button"
              onClick={() => setLiveTab('live')}
              className={`flex-1 rounded-full py-2 text-sm font-semibold transition-all ${
                liveTab === 'live'
                  ? 'bg-[#00E676] text-[#0d0d1a]'
                  : 'bg-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              Live Bets
            </button>
            <button
              type="button"
              onClick={() => setLiveTab('mine')}
              className={`flex-1 rounded-full py-2 text-sm font-semibold transition-all ${
                liveTab === 'mine'
                  ? 'bg-[#00E676] text-[#0d0d1a]'
                  : 'bg-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              My Bets
            </button>
          </div>

          {liveTab === 'live' && (
            <div>
              {/* Column headers */}
              <div className="grid grid-cols-4 px-3 py-2 text-xs text-muted-foreground border-b border-[#2a2a3e]">
                <span>User</span>
                <span className="text-center">Bet KSH</span>
                <span className="text-center">Cashout</span>
                <span className="text-right">Won KSH</span>
              </div>
              {/* Rows */}
              <div className="max-h-80 overflow-y-auto">
                {MOCK_LIVE_BETS.map((bet) => (
                  <div
                    key={bet.id}
                    className="grid grid-cols-4 items-center px-3 py-2 border-b border-[#1e1e30] hover:bg-[#25253d] transition-colors"
                  >
                    {/* User */}
                    <div className="flex items-center gap-2">
                      <div
                        className="h-7 w-7 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-white"
                        style={{ background: bet.color }}
                      >
                        {bet.user[0]}
                      </div>
                      <span className="text-sm text-foreground font-mono">{bet.user}</span>
                    </div>
                    {/* Bet */}
                    <span className="text-center text-sm font-mono text-foreground">
                      {bet.bet.toFixed(2)}
                    </span>
                    {/* Cashout multiplier */}
                    <div className="flex justify-center">
                      <span
                        className="rounded-md px-2 py-0.5 text-xs font-bold font-mono bg-[#12121f]"
                        style={{ color: getCashoutColor(bet.cashout) }}
                      >
                        {bet.cashout.toFixed(2)}x
                      </span>
                    </div>
                    {/* Won */}
                    <span className="text-right text-sm font-mono text-foreground">
                      {bet.won.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {liveTab === 'mine' && (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              {/* Spinning swirl logo */}
              <svg
                className="animate-spin-reverse"
                width="64"
                height="64"
                viewBox="0 0 64 64"
                fill="none"
              >
                {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => {
                  const rad = (deg * Math.PI) / 180
                  const x1 = 32 + 8 * Math.cos(rad)
                  const y1 = 32 + 8 * Math.sin(rad)
                  const x2 = 32 + 26 * Math.cos(rad)
                  const y2 = 32 + 26 * Math.sin(rad)
                  const cp1x = 32 + 15 * Math.cos(rad + 0.4)
                  const cp1y = 32 + 15 * Math.sin(rad + 0.4)
                  return (
                    <path
                      key={deg}
                      d={`M${x1},${y1} Q${cp1x},${cp1y} ${x2},${y2}`}
                      stroke="#00E676"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      opacity="0.8"
                    />
                  )
                })}
                <circle cx="32" cy="32" r="5" fill="#00E676" />
                <circle cx="32" cy="32" r="2.5" fill="#0d0d1a" />
              </svg>
              <p className="text-sm text-muted-foreground">No bets yet this round</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function TabButton({
  label,
  active,
  onClick,
}: {
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex-1 cursor-pointer rounded-full px-6 py-1.5 text-center text-sm font-medium transition-colors ${
        active
          ? 'bg-[#2a2a3e] text-foreground'
          : 'text-muted-foreground hover:text-foreground/70'
      }`}
    >
      {label}
    </button>
  )
}
