import { useState, useRef, useEffect, useCallback } from 'react'

/**
 * Game phases:
 *  waiting  → countdown before a round
 *  flying   → multiplier is climbing, plane moving bottom-left → upper-right
 *  crashing → plane accelerates off screen (0.6s fly-away)
 *  crashed  → shows crash result, then restarts
 */
export type Phase = 'waiting' | 'flying' | 'crashing' | 'crashed'

export interface CurvePoint {
  x: number // 0-1  horizontal (0=left axis, 1=right edge)
  y: number // 0-1  vertical   (0=bottom axis, 1=top edge)
}

export interface PlaneTransform {
  nx: number        // 0-1 horizontal position
  ny: number        // 0-1 vertical position
  angleDeg: number  // nose-up tilt
  crashOffsetX: number
  crashOffsetY: number
  offScreen: boolean
}

export interface GameState {
  phase: Phase
  multiplier: number
  crashPoint: number
  waitProgress: number
  roundHistory: number[]
  trailPoints: CurvePoint[]
  plane: PlaneTransform
}

// ── Constants ────────────────────────────────────────────────────────────────
const WAIT_MS           = 5000
const CRASH_DISPLAY_MS  = 3000
const FLY_AWAY_MS       = 700
const MAX_HISTORY       = 20
const POINT_INTERVAL_MS = 60

// ── Multiplier formula ──────────────────────────────────────────────────────
// e^(0.00006 * t)  →  1× at t=0,  ~2× at ~11.5s
function computeMultiplier(ms: number): number {
  return Math.pow(Math.E, 0.00006 * ms)
}

// Inverse: ms when multiplier = cp
function estimateCrashMs(cp: number): number {
  if (cp <= 1) return 1
  return Math.log(cp) / 0.00006
}

// ── Coordinate mapping ──────────────────────────────────────────────────────
// The plane travels from (0,0) bottom-left diagonally toward (MAX_X, MAX_Y)
// upper-right corner. The curve creates the classic Aviator "hockey stick" 
// shape that starts more horizontal then curves upward exponentially.

const MAX_X = 0.92
const MAX_Y = 0.85

/**
 * Shared progress value 0→1 based on elapsed time vs estimated crash time.
 * Uses a soft exponential ease for smooth motion.
 */
function mapProgress(t: number): number {
  // Smooth ease that continues past t=1
  return 1 - Math.exp(-2.2 * t)
}

/** X position: smooth movement toward MAX_X */
function mapX(t: number): number {
  const p = mapProgress(t)
  return MAX_X * p
}

/**
 * Y position: exponential curve that creates the classic Aviator shape.
 * Starts nearly horizontal, then curves upward steeply at higher multipliers.
 * This matches the authentic Aviator casino game trajectory.
 */
function mapY(_mult: number, _cp: number, t: number): number {
  const p = mapProgress(t)
  // Exponential curve: p^2.2 creates a steeper curve that starts flat
  // and accelerates upward - matching the authentic Aviator look
  return MAX_Y * Math.pow(p, 2.2)
}

/** 
 * Tilt angle: follows the tangent of the curve for realistic plane rotation.
 * Starts at a gentle angle (~15°) and increases as the curve steepens.
 */
function tiltDeg(ny: number): number {
  // Map ny (0→0.85) to angle (12°→45°)
  const ratio = ny / MAX_Y
  // Non-linear mapping for smoother rotation at lower values
  return 12 + Math.pow(ratio, 0.8) * 33
}

function generateCrashPoint(): number {
  const r = Math.random()
  const raw = 1 / (1 - r) * 0.97
  return Math.min(200, Math.max(1.02, raw))
}

const INITIAL_HISTORY = [1.89, 25.04, 1.33, 1.27, 4.40, 2.36, 15.64]

const DEFAULT_PLANE: PlaneTransform = {
  nx: 0, ny: 0, angleDeg: 0,
  crashOffsetX: 0, crashOffsetY: 0, offScreen: false,
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useGameState(): GameState {
  const [phase, setPhase]           = useState<Phase>('waiting')
  const [multiplier, setMultiplier] = useState(1.0)
  const [crashPoint, setCrashPoint] = useState(0)
  const [waitProgress, setWaitProg] = useState(0)
  const [roundHistory, setHistory]  = useState<number[]>(INITIAL_HISTORY)
  const [trailPoints, setTrail]     = useState<CurvePoint[]>([])
  const [plane, setPlane]           = useState<PlaneTransform>(DEFAULT_PLANE)

  const raf        = useRef(0)
  const timeout    = useRef(0)
  const tStart     = useRef(0)
  const cpRef      = useRef(0)
  const phaseRef   = useRef<Phase>('waiting')
  const lastPtMs   = useRef(0)
  const trailBuf   = useRef<CurvePoint[]>([])

  const stop = useCallback(() => {
    if (raf.current) { cancelAnimationFrame(raf.current); raf.current = 0 }
  }, [])

  // ── WAITING ──────────────────────────────────────────────────────────────
  const startWait = useCallback(() => {
    stop()
    if (timeout.current) { clearTimeout(timeout.current); timeout.current = 0 }
    phaseRef.current = 'waiting'
    setPhase('waiting'); setMultiplier(1); setCrashPoint(0); setWaitProg(0)
    setTrail([]); setPlane(DEFAULT_PLANE)
    trailBuf.current = []
    tStart.current = performance.now()

    const tick = (now: number) => {
      if (phaseRef.current !== 'waiting') return
      const el = now - tStart.current
      setWaitProg(Math.min(100, (el / WAIT_MS) * 100))
      if (el >= WAIT_MS) {
        const cp = generateCrashPoint()
        cpRef.current = cp; setCrashPoint(cp)
        startFly(); return
      }
      raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── FLYING ───────────────────────────────────────────────────────────────
  const startFly = useCallback(() => {
    stop()
    phaseRef.current = 'flying'
    lastPtMs.current = 0
    trailBuf.current = [{ x: 0, y: 0 }]
    setPhase('flying'); setMultiplier(1)
    setTrail([{ x: 0, y: 0 }]); setPlane({ ...DEFAULT_PLANE })
    tStart.current = performance.now()

    const tick = (now: number) => {
      if (phaseRef.current !== 'flying') return
      const el   = now - tStart.current
      const mult = computeMultiplier(el)
      const cp   = cpRef.current

      if (mult >= cp) { setMultiplier(cp); startCrash(); return }

      setMultiplier(mult)

      const totalMs = estimateCrashMs(cp)
      const t       = el / totalMs              // raw progress 0→1+
      const nx      = mapX(t)
      const ny      = mapY(mult, cp, t)
      const angle   = tiltDeg(ny)

      // Append trail point
      if (el - lastPtMs.current >= POINT_INTERVAL_MS) {
        lastPtMs.current = el
        const pt: CurvePoint = { x: nx, y: ny }
        trailBuf.current = [...trailBuf.current.slice(-399), pt]
        setTrail([...trailBuf.current])
      }

      setPlane({ nx, ny, angleDeg: angle, crashOffsetX: 0, crashOffsetY: 0, offScreen: false })
      raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── CRASHING (fly-away) ──────────────────────────────────────────────────
  const startCrash = useCallback(() => {
    stop()
    phaseRef.current = 'crashing'
    setPhase('crashing')

    const t0 = performance.now()
    let snapNx = MAX_X, snapNy = MAX_Y
    setPlane(prev => { snapNx = prev.nx; snapNy = prev.ny; return prev })

    const tick = (now: number) => {
      if (phaseRef.current !== 'crashing') return
      const s = (now - t0) / 1000
      const accel = 1 + s * 5
      const offX  = 1.8 * s * accel
      const offY  = -3.0 * s * accel
      const gone  = (snapNx + offX > 1.5) || (snapNy + offY < -0.5)

      setPlane({
        nx: snapNx, ny: snapNy,
        angleDeg: 42 + s * 40,
        crashOffsetX: offX, crashOffsetY: offY,
        offScreen: gone,
      })

      if (s >= FLY_AWAY_MS / 1000) {
        phaseRef.current = 'crashed'
        setPhase('crashed')
        const cv = cpRef.current
        timeout.current = window.setTimeout(() => {
          setHistory(prev => [...prev, cv].slice(-MAX_HISTORY))
          startWait()
        }, CRASH_DISPLAY_MS)
        return
      }
      raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    startWait()
    return () => { stop(); if (timeout.current) clearTimeout(timeout.current) }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return { phase, multiplier, crashPoint, waitProgress, roundHistory, trailPoints, plane }
}
