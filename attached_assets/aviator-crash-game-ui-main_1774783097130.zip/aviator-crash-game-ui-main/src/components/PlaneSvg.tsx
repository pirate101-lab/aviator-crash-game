/**
 * PlaneSvg — Sleek jet/fighter plane silhouette facing right-upward.
 * Green (#00E676) fill, ~60x30px.
 */
export function PlaneSvg({ className }: { className?: string }) {
  return (
    <svg
      width="60"
      height="30"
      viewBox="0 0 60 30"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      {/* Fuselage — pointed nose, tapered body */}
      <path
        d="M2 15 L18 12 L40 8 L52 10 L56 13 L58 15 L56 17 L52 20 L40 22 L18 18 Z"
        fill="#00E676"
      />
      {/* Swept-back top wing */}
      <path
        d="M22 12 L16 2 L20 1 L36 10 Z"
        fill="#00E676"
        opacity="0.9"
      />
      {/* Swept-back bottom wing */}
      <path
        d="M22 18 L16 28 L20 29 L36 20 Z"
        fill="#00E676"
        opacity="0.9"
      />
      {/* Tail fin */}
      <path
        d="M44 10 L42 3 L46 4 L48 10 Z"
        fill="#00E676"
        opacity="0.85"
      />
      {/* Small bottom tail fin */}
      <path
        d="M44 20 L42 27 L46 26 L48 20 Z"
        fill="#00E676"
        opacity="0.85"
      />
      {/* Engine exhaust detail — small circle */}
      <circle cx="54" cy="15" r="2" fill="#00E676" opacity="0.5" />
      <circle cx="56" cy="15" r="1" fill="#00E676" opacity="0.3" />
      {/* Cockpit window */}
      <ellipse cx="12" cy="15" rx="3" ry="1.5" fill="#0d0d1a" opacity="0.6" />
      {/* Wing highlight line */}
      <line
        x1="20"
        y1="14"
        x2="38"
        y2="12"
        stroke="#0d0d1a"
        strokeWidth="0.5"
        opacity="0.3"
      />
      <line
        x1="20"
        y1="16"
        x2="38"
        y2="18"
        stroke="#0d0d1a"
        strokeWidth="0.5"
        opacity="0.3"
      />
    </svg>
  )
}
