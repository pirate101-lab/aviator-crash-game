import { useState } from 'react'
import { Header } from './components/Header'
import { RoundHistory } from './components/RoundHistory'
import { GameCanvas } from './components/GameCanvas'
import BetPanel from './components/BetPanel'
import { useGameState } from './hooks/useGameState'

function App() {
  const game = useGameState()
  const [betMode, setBetMode] = useState<'money' | 'freebet'>('money')

  return (
    <div className="min-h-screen bg-[#0d0d1a] text-[#cdd2db]">
      <Header balance={0.0} />
      <RoundHistory history={game.roundHistory} />

      <div className="px-3 py-2">
        <GameCanvas
          phase={game.phase}
          multiplier={game.multiplier}
          crashPoint={game.crashPoint}
          waitProgress={game.waitProgress}
          trailPoints={game.trailPoints}
          plane={game.plane}
          betMode={betMode}
          onToggleBetMode={() =>
            setBetMode((m) => (m === 'money' ? 'freebet' : 'money'))
          }
        />
      </div>

      <div className="flex flex-col gap-3 px-3 pb-6">
        <BetPanel defaultAmount={10.84} currency="KSH" />
        <BetPanel defaultAmount={70} currency="KSH" showLiveBets={true} />
      </div>
    </div>
  )
}

export default App
