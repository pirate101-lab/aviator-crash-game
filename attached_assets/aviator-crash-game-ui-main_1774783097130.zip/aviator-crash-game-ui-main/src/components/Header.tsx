import { useState } from 'react'

interface HeaderProps {
  balance: number
}

function ToggleSwitch({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors duration-200 ${
        on ? 'bg-[#00E676]' : 'bg-[#3a3a4e]'
      }`}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform duration-200 ${
          on ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </button>
  )
}

export function Header({ balance }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const [soundOn, setSoundOn] = useState(false)
  const [musicOn, setMusicOn] = useState(false)
  const [animationOn, setAnimationOn] = useState(true)

  return (
    <header className="relative flex items-center justify-between bg-[#1a1a2e] px-4 py-2.5 border-b border-[#2a2a3e]">
      {/* Left — Logo */}
      <div className="flex flex-col leading-tight">
        <span className="text-lg font-bold text-[#00E676] tracking-tight">
          Aviator
        </span>
        <span className="text-xs text-[#888888]">Crash</span>
      </div>

      {/* Right — Balance, Deposit, Icons */}
      <div className="flex items-center gap-2">
        {/* Balance */}
        <div className="flex items-center gap-1 text-sm font-mono">
          <span className="text-[#888888]">KSH</span>
          <span className="text-[#00E676] font-semibold">
            {balance.toLocaleString('en-US', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        </div>

        {/* Deposit button */}
        <button
          type="button"
          className="bg-[#00E676] text-[#0d0d1a] font-bold rounded-md px-3 py-1.5 text-sm transition-transform duration-150 hover:scale-105 active:scale-95"
        >
          Deposit
        </button>

        {/* Hamburger icon — opens settings menu */}
        <button
          type="button"
          aria-label="Menu"
          onClick={() => { setMenuOpen(v => !v); setUserOpen(false) }}
          className="flex flex-col justify-center items-center gap-[3px] p-2 rounded-md transition-colors duration-150 hover:bg-[#25253d]"
        >
          <span className="block w-4 h-[2px] bg-[#888888] rounded-full" />
          <span className="block w-4 h-[2px] bg-[#888888] rounded-full" />
          <span className="block w-4 h-[2px] bg-[#888888] rounded-full" />
        </button>

        {/* User icon — shows user info */}
        <button
          type="button"
          aria-label="User Profile"
          onClick={() => { setUserOpen(v => !v); setMenuOpen(false) }}
          className="p-2 rounded-md transition-colors duration-150 hover:bg-[#25253d]"
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#888888"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
          </svg>
        </button>
      </div>

      {/* Settings Menu Dropdown */}
      {menuOpen && (
        <div
          className="absolute right-2 top-full mt-1 z-50 w-72 rounded-xl bg-[#1e1e30] border border-[#2a2a3e] shadow-2xl overflow-hidden animate-fade-in"
          onClick={e => e.stopPropagation()}
        >
          {/* User profile header */}
          <div className="flex items-center gap-3 p-4 border-b border-[#2a2a3e]">
            {/* Colorful avatar */}
            <div className="h-12 w-12 rounded-full overflow-hidden bg-gradient-to-br from-pink-500 via-purple-500 to-cyan-400 flex items-center justify-center">
              <svg width="28" height="28" viewBox="0 0 40 40" fill="none">
                <ellipse cx="20" cy="14" rx="8" ry="8" fill="#0d0d1a" opacity="0.5"/>
                <path d="M8 36c0-6.6 5.4-12 12-12s12 5.4 12 12" fill="#0d0d1a" opacity="0.4"/>
                <circle cx="20" cy="14" r="6" fill="url(#av)"/>
                <defs>
                  <radialGradient id="av" cx="40%" cy="35%">
                    <stop stopColor="#ff6eb4"/>
                    <stop offset="1" stopColor="#a855f7"/>
                  </radialGradient>
                </defs>
              </svg>
            </div>
            <span className="text-lg font-bold text-foreground flex-1">Gxbd</span>
            <button
              type="button"
              className="flex items-center gap-1.5 rounded-full border border-[#3a3a4e] bg-[#2a2a3e] px-3 py-1.5 text-xs text-muted-foreground hover:border-[#00E676]/30 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
              </svg>
              Change Avatar
            </button>
          </div>

          {/* Toggle settings */}
          <div className="p-2">
            {[
              { icon: '🔊', label: 'Sound', value: soundOn, toggle: () => setSoundOn(v => !v) },
              { icon: '🎵', label: 'Music', value: musicOn, toggle: () => setMusicOn(v => !v) },
              { icon: '🎮', label: 'Animation', value: animationOn, toggle: () => setAnimationOn(v => !v) },
            ].map(({ icon, label, value, toggle }) => (
              <div key={label} className="flex items-center justify-between rounded-lg px-3 py-3 hover:bg-[#25253d] transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-base">{icon}</span>
                  <span className="text-sm text-foreground">{label}</span>
                </div>
                <ToggleSwitch on={value} onToggle={toggle} />
              </div>
            ))}
          </div>

          <div className="border-t border-[#2a2a3e]" />

          {/* Menu links */}
          <div className="p-2">
            {[
              { icon: '👤', label: 'My Profile' },
              { icon: '👥', label: 'Refer and Earn' },
              { icon: '🔥', label: 'Bonuses & Promotions' },
              { icon: '🔗', label: 'About Us' },
              { icon: '🚪', label: 'Logout' },
            ].map(({ icon, label }) => (
              <button
                key={label}
                type="button"
                className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm text-foreground hover:bg-[#25253d] transition-colors text-left"
              >
                <span className="text-base">{icon}</span>
                {label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* User Info Dropdown */}
      {userOpen && (
        <div
          className="absolute right-2 top-full mt-1 z-50 w-64 rounded-xl bg-[#1e1e30] border border-[#2a2a3e] shadow-2xl overflow-hidden animate-fade-in"
          onClick={e => e.stopPropagation()}
        >
          <div className="p-4 flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-gradient-to-br from-pink-500 via-purple-500 to-cyan-400 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="8" r="4" fill="#0d0d1a" opacity="0.4"/>
                  <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" fill="#0d0d1a" opacity="0.3"/>
                </svg>
              </div>
              <div>
                <p className="font-bold text-foreground">Gxbd</p>
                <p className="text-xs text-muted-foreground">Player ID: #38291</p>
              </div>
            </div>
            <div className="rounded-lg bg-[#12121f] p-3">
              <p className="text-xs text-muted-foreground mb-1">Balance</p>
              <p className="text-lg font-bold font-mono text-[#00E676]">
                KSH {balance.toFixed(2)}
              </p>
            </div>
            <div className="rounded-lg bg-[#12121f] p-3">
              <p className="text-xs text-muted-foreground mb-1">Freebet</p>
              <p className="text-lg font-bold font-mono text-foreground">
                KSH 0.00
              </p>
            </div>
            <button
              type="button"
              className="w-full rounded-lg bg-[#00E676] py-2 text-sm font-bold text-[#0d0d1a] hover:brightness-110 transition-all"
            >
              Deposit
            </button>
          </div>
        </div>
      )}

      {/* Click-outside backdrop */}
      {(menuOpen || userOpen) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => { setMenuOpen(false); setUserOpen(false) }}
        />
      )}
    </header>
  )
}
